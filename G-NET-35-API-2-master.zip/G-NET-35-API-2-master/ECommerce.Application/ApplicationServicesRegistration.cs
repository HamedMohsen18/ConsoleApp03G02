﻿using ECommerce.Application.Contracts;
using ECommerce.Application.Services;
using Microsoft.Extensions.DependencyInjection;

namespace ECommerce.Application
{
    public static class ApplicationServicesRegistration
    {
        public static IServiceCollection AddApplicationServices(this IServiceCollection services)
        {
            services.AddAutoMapper(_ => { }, typeof(ApplicationServicesRegistration));

            services.AddScoped<IProductService, ProductService>();

            return services;
        }

    }
}
