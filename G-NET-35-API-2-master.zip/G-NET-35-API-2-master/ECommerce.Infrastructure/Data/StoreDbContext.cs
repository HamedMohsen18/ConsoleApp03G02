﻿using ECommerce.Domain.Entities.Products;
using Microsoft.EntityFrameworkCore;

namespace ECommerce.Infrastructure.Data
{
    internal class StoreDbContext(DbContextOptions<StoreDbContext> options) : DbContext(options)
    {
        public DbSet<Product> GetProducts()
        {
            return Set<Product>();
        }

        public DbSet<ProductBrand> GetProductBrands()
        {
            return Set<ProductBrand>();
        }

        public DbSet<ProductType> GetProductTypes()
        {
            return Set<ProductType>();
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(typeof(StoreDbContext).Assembly);
        }

    }
}
