﻿using E_Commerce.Application.Common;
using E_Commerce.Application.DTOs.Authentications;

namespace E_Commerce.Application.Contracts
{
    public interface IIdentityService
    {
        Task<Result<IdentityUserResult>> FindByEmailAsync(string email, CancellationToken cancellationToken = default);
        Task<Result<bool>> CheckPasswordAsync(string email, string password, CancellationToken cancellationToken = default);
        Task<Result<IdentityUserResult>> CreateUserAsync(RegisterDto registerDto, CancellationToken cancellationToken = default);

    }
}
