﻿using E_Commerce.Domain.Entities.Products;

namespace E_Commerce.Application.Specifications
{
    internal class ProductsWithIdsSpecifications : BaseSpecification<Product, int>
    {
        public ProductsWithIdsSpecifications(HashSet<int> productIds) : base(p => productIds.Contains(p.Id))
        {

        }
    }
}
