﻿using ECommerce.Domain.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace ECommerce.Domain.Entities.Products;

public class Product : BaseEntity<int>
{
    public string Name { get; set; } = default!;
    public string Description { get; set; } = default!;
    public string PictureUrl { get; set; } = default!;
    public decimal Price { get; set; }

    public ProductsBrand Brand { get; set; } = default!;

    [ForeignKey("Brand")]
    public int BrandId { get; set; }

    public ProductsType Type { get; set; } = default!;

    [ForeignKey("Type")]
    public int TypeId { get; set; }

}
