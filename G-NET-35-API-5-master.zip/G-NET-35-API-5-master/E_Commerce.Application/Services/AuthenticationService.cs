﻿using E_Commerce.Application.Common;
using E_Commerce.Application.Contracts;
using E_Commerce.Application.DTOs.Authentications;

namespace E_Commerce.Application.Services
{
    internal class AuthenticationService(IIdentityService identityService) : IAuthenticationService
    {
        private readonly IIdentityService _identityService = identityService;

        public async Task<Result<UserDto>> LoginAsync(LoginDto loginDto, CancellationToken cancellationToken = default)
        {
            var userResult = await _identityService.FindByEmailAsync(loginDto.Email, cancellationToken);
            if (!userResult.IsSuccess)
                return Result<UserDto>.Fail(userResult.Errors);

            if (userResult.Data is null)
                return Result<UserDto>.Fail(userResult.Errors);

            var passwordResult = await _identityService.CheckPasswordAsync(loginDto.Email, loginDto.Password, cancellationToken);
            if (!passwordResult.IsSuccess)
                return Result<UserDto>.Fail(Error.Unauthorized("Invalid Email or Password"));

            return new UserDto
            {
                Email = userResult.Data.Email ?? string.Empty,
                DisplayName = userResult.Data.DisplayName,
                Token = "Token"
            };
        }

        public async Task<Result<UserDto>> RegisterAsync(RegisterDto registerDto, CancellationToken cancellationToken = default)
        {
            var result = await _identityService.CreateUserAsync(registerDto, cancellationToken);
            if (!result.IsSuccess || result.Data is null)
                return Result<UserDto>.Fail(result.Errors);

            return new UserDto { Email = result.Data.Email ?? string.Empty, DisplayName = result.Data.DisplayName, Token = "Token" };
        }
    }
}
