﻿using E_Commerce.Domain.Common;
using System.Linq.Expressions;

namespace E_Commerce.Domain.Contracts
{
    public interface ISpecifications<TEntity, TKey> where TEntity : BaseEntity<TKey>
    {
        ICollection<Expression<Func<TEntity, object>>> IncludeExpressions { get; }
        Expression<Func<TEntity, bool>> Criteria { get; }
        Expression<Func<TEntity, object>>? Orderby { get; }
        Expression<Func<TEntity, object>>? OrderbyDescending { get; }
        int Take { get; }
        int Skip { get; }
        bool IsPaginated { get; }
    }
}
