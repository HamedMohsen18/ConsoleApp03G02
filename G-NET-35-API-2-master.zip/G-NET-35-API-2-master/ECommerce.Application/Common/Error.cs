﻿namespace ECommerce.Application.Common
{
    public sealed record Error(string Code, string Description, ErrorType Type = ErrorType.Failure)
    {
        public static Error Failure(string code = "General.Failure", string description = "A general failure has occurred.")
        {
            return new(code, description, ErrorType.Failure);
        }

        public static Error Validation(string code = "General.Validation", string description = "A validation error has occurred.")
        {
            return new(code, description, ErrorType.Validation);
        }

        public static Error NotFound(string code = "General.NotFound", string description = "The requested resource was not found.")
        {
            return new(code, description, ErrorType.NotFound);
        }

        public static Error Conflict(string code = "General.Conflict", string description = "A conflict occurred with the current state.")
        {
            return new(code, description, ErrorType.Conflict);
        }

        public static Error Unauthorized(string code = "General.Unauthorized", string description = "Access is denied due to lack of authorization.")
        {
            return new(code, description, ErrorType.Unauthorized);
        }

        public static Error Forbidden(string code = "General.Forbidden", string description = "The operation is forbidden.")
        {
            return new(code, description, ErrorType.Forbidden);
        }

        public static Error InvalidCredentials(string code = "General.InvalidCredentials", string description = "The provided credentials are invalid.")
        {
            return new(code, description, ErrorType.InvalidCredentials);
        }

    }

}
