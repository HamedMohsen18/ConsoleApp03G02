﻿using System.Text.Json.Serialization;

namespace ECommerce.Application.Common
{

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum ErrorType
    {
        Failure = 0,
        Validation,
        NotFound,
        Conflict,
        Unauthorized,
        Forbidden,
        InvalidCredentials
    }

}
