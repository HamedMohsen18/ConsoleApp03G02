﻿using ECommerce.Domain.Entities.Products;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace ECommerce.Infrastructure.Configurations;

public class ProductConfigurations : IEntityTypeConfiguration<Product>
{
    public void Configure(EntityTypeBuilder<Product> builder)
    {
        builder.Property(p => p.Name).IsRequired().HasMaxLength(100);

        builder.Property(p => p.PictureUrl).IsRequired().HasMaxLength(200);

        builder.Property(p => p.Description).IsRequired().HasMaxLength(500);

        builder.Property(p => p.Price).HasColumnType("decimal(18,2)");
    }
}
