﻿using ECommerce.Application.Common;
using ECommerce.Application.DTOs.Product;

namespace ECommerce.Application.Contracts
{
    public interface IProductService
    {

        Task<Result<IReadOnlyList<ProductDto>>> GetAllProductsAsync(CancellationToken ct = default);

        Task<Result<ProductDto>> GetProductAsync(int id, CancellationToken ct = default);

        Task<Result<IReadOnlyList<BrandDto>>> GetAllBrandsAsync(CancellationToken ct = default);

        Task<Result<IReadOnlyList<TypeDto>>> GetAllTypesAsync(CancellationToken ct = default);

    }
}
