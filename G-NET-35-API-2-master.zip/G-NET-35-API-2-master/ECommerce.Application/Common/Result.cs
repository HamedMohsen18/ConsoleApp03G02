﻿namespace ECommerce.Application.Common
{
    public class Result
    {
        public bool IsSuccess { get; }
        public IReadOnlyList<Error> Errors { get; }

        protected Result(bool isSuccess, IReadOnlyList<Error> errors)
        {
            IsSuccess = isSuccess;
            Errors = errors;
        }

        public static Result Ok()
        {
            return new(true, Array.Empty<Error>());
        }

        public static Result Fail(Error error)
        {
            return new(false, [error]);
        }

        public static Result Fail(IReadOnlyList<Error> errors)
        {
            return new(false, errors);
        }

    }

    public class Result<TValue> : Result
    {
        private readonly TValue _value;

        public TValue Data => IsSuccess ? _value : throw new InvalidOperationException("Cannot access the value of a failed result.");

        private Result(TValue value) : base(true, Array.Empty<Error>())
        {
            _value = value;
        }

        private Result(Error error) : base(false, [error])
        {
            _value = default!;
        }

        private Result(IReadOnlyList<Error> errors) : base(false, errors)
        {
            _value = default!;
        }

        public static Result<TValue> Ok(TValue value)
        {
            return new(value);
        }

        public static new Result<TValue> Fail(Error error)
        {
            return new(error);
        }

        public static new Result<TValue> Fail(IReadOnlyList<Error> errors)
        {
            return new(errors);
        }

        public static implicit operator Result<TValue>(TValue value)
        {
            return Ok(value);
        }

        public static implicit operator Result<TValue>(Error error)
        {
            return Fail(error);
        }

    }

}
